window.onload = function() {
  tl = new TimelineLite();
var F1 = document.getElementById("descF1");
var F2 = document.getElementById("descF2");
var F3 = document.getElementById("descF3");
var partners = document.getElementById("partners");
var logo=document.getElementById("logo");
var imgLogo=document.getElementById("nameComp");

function restartAnimation(){

  tl = new TimelineLite();
  F1.removeAttribute('style');
  F2.removeAttribute('style');
  logo.removeAttribute('style');
  F3.removeAttribute('style');
    partners.removeAttribute('style');
  imgLogo.removeAttribute('style');
    startAnimation();
}
startAnimation();
function startAnimation(){
  tl.to(partners, 15, {'left':"-366"})
    .to(F1, 2, {'left':"-240"},3)
    .to(F2, 2, {'left':"0"},3)

    .to(F2, 2, {'left':"-240"},8)
    .to(logo,0.4,{'left':54},8)
    .to(imgLogo,0.4,{'width':140},8.4)
    .to(logo,1.5,{'top':121,'width':128,'height':31,'background-size':'cover'},8.8)

    .to(F3, 2, {'left':"0"},8.8)
    .to(F3, 2, {onComplete:restartAnimation},15);

}

}
