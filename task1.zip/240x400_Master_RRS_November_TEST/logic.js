'use strict';
var rim = document.getElementById('rim'),
	rimContainer = document.getElementById('rimContainer'),
	bg = document.getElementById('bg'),
	road = document.getElementById('road'),
	car = document.getElementById('car'),
	whiteArea = document.getElementById('whiteArea'),
	snowSmall = document.getElementById('snowSmall'),
	logo = document.getElementById('logo'),
	namePlate = document.getElementById('namePlate'),
	headline1 = document.getElementById('headline1'),
	headline2 = document.getElementById('headline2'),
	headline3 = document.getElementById('headline3'),
	cta = document.getElementById('cta'),
	care = document.getElementById('care'),
	copy = document.getElementById('copy'),
	disclamer = document.getElementById('disclamer'),
	scrollingButton = document.getElementById('scrollingButton'),
	dealer = document.getElementById('dealer'),

	playFlag = true,
	scrollingFlag = false,
	speed = 0.27,
	tl = new TimelineLite();
;

function restartAnimation(){
	TweenMax.killAll();
	tl = new TimelineLite();
	TweenMax.to([car, snowSmall, snow, whiteArea], 0, {x:0, y:0, scale:1})
	rimMooving();
	startAnimation();
}

function startAnimation(){
	tl.to(intro, 0, {opacity: 0}, 0)
	.to(intro, 0.5, {opacity: 1}, 0)
	.to(car, 0.25, {x: 30, y:2}, 0)
	.to(bg, 15, {x: -60}, 0)
	.to(snowSmall, 5, {scaleX: 1.8, scaleY: 1.2, opacity:0.5}, 0)

	.to(car, 2, {ease: Power0.easeNone, x: 60, y:5, onStart:slowMoOn}, 0.25)
	.to(snow, 15, {scale:4}, 0.25)

	.to(car, 1.25, {ease: Power2.easeInOut, x: 650, y:60, onStart:slowMoOff}, 2)
	// .to(bg, 1.25, {x: -0}, 2)
	.to(snow, 1.25, {ease: Power2.easeInOut, x:-100, y:-30, scaleX:4, scaleY:3}, 2)
	.to(snowSmall, 1.25, {ease: Power2.easeInOut, x:-200, opacity:0}, 2)
	.to(whiteArea, 1.5, {ease: Power4.easeInOut, y: -677}, 2.15)

	.to(kv, 0, {opacity:1}, 2.85)
	.to(logo, 3, {opacity:1}, 3.25)
	.to(namePlate, 3, {opacity:1}, 3.5)
	.to(headline1, 3, {opacity:1}, 3.75)
	.to(cta, 3, {opacity:1}, 4)


	.to(headline1, 0.25, {opacity:0}, 7)
	.to(headline2, 1, {opacity:1}, 7.25)

	.to(headline2, 0.25, {opacity:0}, 9)
	.to(headline3, 1, {opacity:1}, 9.25)

	.to([namePlate, headline3, cta, intro, kv], 0.25, {opacity:0}, 10.75)
	//.to([copy, care], 1, {opacity:1}, 11)

	.to([copy, care, logo], 0.25, {opacity:0}, 10.75)
	.to([disclamer, scrolling], 1, {opacity:1, onStart:scrollingOn}, 11)

	.add('endBanner', 18)
	.to([disclamer, scrolling], 0.25, {opacity:0, onStart:scrollingOff}, 18)

	.to([dealer, kv, logo, cta], 0.5, {opacity:1}, 18)
	.to([dealer, kv, logo, cta], 0.25, {opacity:0, onComplete:restartAnimation}, 18);
}

function slowMoOn(){ speed = 1.5; }
function slowMoOff(){ speed = 0.27; rimMooving();}

function scrollingOn(){
	scrolling.style.pointerEvents = 'auto';
	scrollingButton.style.top = 0;
	disclamer.style.top = 0;
}
function scrollingOff(){
	scrolling.style.pointerEvents = 'none';
}
function playPauseClick(){
	if(playFlag){
		tl.pause();
		playFlag = false;
		playPause.style.backgroundPosition = '-170px -16px';
	}else{
		restartAnimation();
		tl.seek('endBanner');
		playFlag = true;
		playPause.style.backgroundPosition = '-170px -34px';
	}
}


function rimMooving(){
	TweenMax.to(rim, 0, {rotation: 0});
	TweenMax.to(rim, speed, {rotation: 360, ease: Power0.easeNone, onComplete:rimMooving});
}


function bannerRollOver(){
	TweenMax.to(ctaArrow, 0, {opacity: 1, x: 0});
	TweenMax.to(ctaArrow, 0.2, {opacity:0, x: 10, ease: Power1.easeIn, onComplete: ctaArrowBack});
	function ctaArrowBack(){
		TweenMax.to(ctaArrow, 0, {x: -10});
		TweenMax.to(ctaArrow, 0.3, {opacity:1, x: 0, ease: Power1.easeOut});
	}
}

function init(){
	console.log('banner loaded');

	TweenMax.to(rimContainer, 0, {scaleX:0.65, scaleY:0.95});

	rimMooving();
	startAnimation();
	border.style.opacity = 1;
	banner.style.opacity = 1;


	playPause.addEventListener('click', playPauseClick);
	btn.addEventListener('mouseover', bannerRollOver);
	scrollingButton.addEventListener('mousedown', sliderButtonMouseDown);
	document.addEventListener('mouseup', sliderButtonMouseUp);
	startAnimation();
}

window.addEventListener('load', init);
