//--функционал скроллинга----------------------------------------------------------------------------------------------------------------------
function sliderButtonMouseDown(){                          
    scrollingFlag = true;
    document.addEventListener('mousemove', startDrag);           //начало отслеживания координат ползунка
}
function sliderButtonMouseUp(){                            
    if(scrollingFlag){
        scrollingFlag = false;
        document.removeEventListener('mousemove', startDrag);    //закончили отслеживание координат ползунка
    }
}
function startDrag(e){
    positionYScrollingButtnon = e.pageY - 26;
    percentScrollingButtonTop = Math.floor(positionYScrollingButtnon * 100 / scrolling.offsetHeight); //узнали процент на сколько отодвинут ползунок 
    if(percentScrollingButtonTop <= 0){
        scrollingFlag = false;
        document.removeEventListener('mousemove', startDrag); //когда число ползунка меньше 0% - остонавливаем прокрутку
        percentScrollingButtonTop = 0;
    }
    if(percentScrollingButtonTop >= 100){
        scrollingFlag = false;
        document.removeEventListener('mousemove', startDrag); //когда число ползунка больше 100% - остонавливаем прокрутку
        percentScrollingButtonTop = 100;
    }
    disclamer.style.top = -(percentScrollingButtonTop * disclamer.scrollHeight / 100 - positionYScrollingButtnon) + 'px';

    if(positionYScrollingButtnon >= banner.offsetHeight - 50){  // запрещаем ползунку пересекать нижнюю границу
        scrollingButton.style.top = banner.offsetHeight - 50 + 'px';
    }
    else if(positionYScrollingButtnon <= 0){
        scrollingButton.style.top = 0 + 'px';               // запрещаем ползунку пересекать верхнюю границу
    }
    else{
        scrollingButton.style.top = positionYScrollingButtnon + 'px';    //ползунок выравнивается с курсором по осям
    }
}//---------------------------------------------------------------------------------------------------------------------------------------------







//** запрещаем выделение текста
function preventSelection(element){
  var preventSelection = false;

  function addHandler(element, event, handler){
    if (element.attachEvent) 
      element.attachEvent('on' + event, handler);
    else 
      if (element.addEventListener) 
        element.addEventListener(event, handler, false);
  }
  function removeSelection(){
    if (window.getSelection) { window.getSelection().removeAllRanges(); }
    else if (document.selection && document.selection.clear)
      document.selection.clear();
  }
  function killCtrlA(event){
    var event = event || window.event;
    var sender = event.target || event.srcElement;

    if (sender.tagName.match(/INPUT|TEXTAREA/i))
      return;

    var key = event.keyCode || event.which;
    if (event.ctrlKey && key == 'A'.charCodeAt(0))  // 'A'.charCodeAt(0) можно заменить на 65
    {
      removeSelection();

      if (event.preventDefault) 
        event.preventDefault();
      else
        event.returnValue = false;
    }
  }

  // не даем выделять текст мышкой
  addHandler(element, 'mousemove', function(){
    if(preventSelection)
      removeSelection();
  });
  addHandler(element, 'mousedown', function(event){
    var event = event || window.event;
    var sender = event.target || event.srcElement;
    preventSelection = !sender.tagName.match(/INPUT|TEXTAREA/i);
  });

  // борем dblclick
  // если вешать функцию не на событие dblclick, можно избежать
  // временное выделение текста в некоторых браузерах
  addHandler(element, 'mouseup', function(){
    if (preventSelection)
      removeSelection();
    preventSelection = false;
  });

  // борем ctrl+A
  // скорей всего это и не надо, к тому же есть подозрение
  // что в случае все же такой необходимости функцию нужно 
  // вешать один раз и на document, а не на элемент
  addHandler(element, 'keydown', killCtrlA);
  addHandler(element, 'keyup', killCtrlA);
}

preventSelection(document);
//** закончился функционалзапрета на выделение текста

